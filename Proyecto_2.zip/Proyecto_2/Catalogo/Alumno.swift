
import Foundation

struct Alumno{
    var nombre: String //articulo
    var apellidos: String // Descripcion
    var promedio: Double = 0.0 //precio
    var foto: String
    var cantidad: Double = 0.0
    //var imagen: String
    // var total: Double 0.0
}



import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var foto: UIImageView!
    @IBOutlet weak var caja: UITextField!
    @IBOutlet weak var nombre: UILabel!
    @IBOutlet weak var apellidos:  UILabel!
    @IBOutlet weak var precio: UILabel!
    
    var dato: Alumno!
    
    var firstView : ViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        precio.text = String(dato.promedio)
        nombre.text = dato.nombre
        apellidos.text = dato.apellidos
        foto.image = UIImage(named: dato.foto)
        foto.layer.cornerRadius = 80
        foto.clipsToBounds = true
        caja.layer.cornerRadius = 25
        
    }
    
    @IBAction func actualizar(_ sender: UIButton) {
        if let valor = caja.text{
            let indexPath = firstView.tablita.indexPathForSelectedRow
            firstView.alumnos[(indexPath?.row)!].cantidad = Double(valor) ?? 0.0
        }
        
    }
    
    @IBAction func salirda(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
   
    
}

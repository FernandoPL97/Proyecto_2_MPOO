
import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tablita: UITableView!
    @IBOutlet weak var etiqueta: UILabel!
    
    @IBOutlet weak var logo: UIImageView!
    
    
    
    var alumnos: [Alumno] = [
        Alumno(nombre:"Push Up Bra Plunge", apellidos: "Bra Demi de Plunge Características: Delicada transparencia en escote Detalles satinados Beneficios: Satinado Soporte Composición: Encaje: 83% Poliamida, 17% Elastano", promedio: 349.99, foto: "productobra", cantidad: 0),
        
        Alumno(nombre: "Babyboll", apellidos: "Babydoll con cintas en escote Características: Incluye Tanga Copa Preformada Beneficios: Tirantes ajustables Composición: Tul poliamida: 91% Poliamida, 9% Elastano", promedio: 449.99, foto: "babyproducto", cantidad: 0),
        
        Alumno(nombre: "Push Up Bra con Encaje", apellidos: "Bra Demi de Encaje Características: Cómodo encaje elástico en torso Tirantes ajustables Beneficios: Soporte Composición: Microfibra: 85% Poliamida, 15% Elastano Microfibra estampada: 85% Poliamida, 15% Elastano Encaje: 89% Poliamida, 11% Elastano", promedio: 349.99, foto: "productobra2", cantidad: 0),
        
        Alumno(nombre: "Bra Copa Completa", apellidos: "Bra Demi Copa Completa Características: Tirantes anchos para mayor comodidad Cojines removibles Beneficios: Soporte Composición: Canesú: 87% Poliamida, 13% Elastano", promedio: 349.99, foto: "productobracom", cantidad: 0),
        
        Alumno(nombre: "Bra Ilusion", apellidos: "Bra Diseño Ilusion Características: Detalle de encaje satinado en copas Tirantes ajustables Beneficios: Soporte Composición: Microfibra: 85% Poliamida, 15% Elastano Encaje: 63% Poliamida, 25% Poliéster, 12% Elastano", promedio: 399.99, foto: "productobrailusion", cantidad: 0),
        Alumno(nombre: "Corpiño Satinado", apellidos: "Descripción Corpiño Satinado Características: Suave encaje en escote Tirantes elásticos Beneficios: Satinado Composición: Satín ligero: 96% Poliamida, 4% Elastano", promedio: 249.99, foto: "productocorpiño", cantidad: 0),
        
        Alumno(nombre: "Corpiño Encaje en Escote", apellidos: "Descripción Corpiño con escote de encaje Características: Tirantes ajustables Antiestático que no se pega Beneficios: Regular Composición: Antiestático: 100% Poliamida", promedio: 249.99, foto: "productocorpiñoescote", cantidad: 0),
        
        Alumno(nombre: "Paquete térmico", apellidos: "Paquete térmico Descripción Paquete térmico Características: Incluye playera y pantalón Ideal para usar en temporada fría Beneficios: Tejido funcional Composición: Chari: 82% poliéster, 18% Elastano", promedio: 249.99, foto: "productotermico", cantidad: 0)
    
    ]
    
    
    @IBOutlet weak var carito: UIImageView!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        promedio()
        
        carito.layer.cornerRadius = 15
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        promedio()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return alumnos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "celda", for: indexPath)
        
        cell.textLabel?.text = alumnos[indexPath.row].nombre
        cell.imageView!.image = UIImage(named: alumnos[indexPath.row].foto)
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let optionMenu = UIAlertController(title: "Visualizar producto", message: "¿Desea visualizar este producto?", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "Cancelar", style: .cancel, handler: nil)
        let okAction = UIAlertAction(title: "OK", style: .default) { (action : UIAlertAction) in
            let celda = tableView.cellForRow(at: indexPath)
            
            if celda?.accessoryType.rawValue == 0{
            }else{
                celda?.accessoryType = .none
            }
            
            self.performSegue(withIdentifier: "toSecondView", sender: self)
        }
        
        optionMenu.addAction(cancelAction)
        optionMenu.addAction(okAction)
        
        present(optionMenu, animated: true, completion: nil)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let indexPath = tablita.indexPathForSelectedRow
        let secondView = segue.destination as? SecondViewController
        secondView?.dato = alumnos[(indexPath?.row)!]
        secondView?.firstView = self
    }
    
    func promedio(){
        var promedio = 0.0
        var total = 0.0
        for alumno in alumnos{
            total = total + alumno.promedio * alumno.cantidad
        }
        promedio = total
        etiqueta.text = String(promedio)
    }
    
    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        if identifier == "toSecondView"{
            return false
        }
        return true
    }


}

